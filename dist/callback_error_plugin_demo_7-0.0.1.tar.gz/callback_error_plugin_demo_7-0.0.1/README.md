# Dash Error Plugin Demo

A Dash plugin to display callback errors in your Dash app.

## Installation

```bash
pip install callback-error-plugin_demo_7
```

## Usage

```python
from dash import Dash, dcc, html, callback, Input, Output, State
import callback_error_plugin_demo_7

add_error_notifications("Error message")

app = Dash(__name__)

app.layout = html.Div(
    [
        html.H2("Division Calculator"),
        generate_error_notification(),
        html.Label("Enter a number:", htmlFor="input-number"),
        dcc.Input(id="input-number", type="number", value=1),
        html.Button("Calculate", id="calc-btn", nClicks=0),
        html.Div(id="output-div"),
    ]
)

@callback(
    Output("output-div", "children"),
    Input("calc-btn", "nClicks"),
    State("input-number", "value"),
)
def update_output(n_clicks, value):
    if not n_clicks:
        return ""
    try:
        result = 10 / value
        return f"The result is {result}"
    except Exception as e:
        return f"Error: {e}"

if __name__ == "__main__":
    app.run(debug=True)
```

## Running the Example

```bash
python example.py
```
